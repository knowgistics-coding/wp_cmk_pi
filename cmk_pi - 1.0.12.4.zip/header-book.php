<?php
$mastheadStart = '<button id="sidebar-toggle"><i class="fas fa-bars"></i></button>';
require(__DIR__."/header.php");